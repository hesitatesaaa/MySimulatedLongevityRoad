using System;
using System.Collections.Generic;
using System.Linq;
using MySimulatedLongevityRoad.Core;
using MySimulatedLongevityRoad.Data;
using MySimulatedLongevityRoad.Traits;
using MySimulatedLongevityRoad.Queries;
using Newtonsoft.Json;
using UnityEngine;

namespace MySimulatedLongevityRoad.Systems.Combat;

internal static partial class MclslCareerCombat
{
    private const string SaveKey="mclsl.080.combat_career.battle.v2";
    private static readonly Dictionary<long,MclslCareerBattleState> Battles = new();
    private static readonly Dictionary<long,long> SummonOwners = new();
    private static double Now => MclslSpellCasting.Now;
    // 契约宠物手动结算伤害时置位，避免 SummonDamage 对同一笔伤害二次加成。
    private static bool _directPetDamage;
    internal static void Init()
    {
        foreach(string id in new[]{"casting","slow","break","interrupt"})
        {
            var status=new StatusAsset { id="mclsl_career_"+id,duration=4,base_stats=new BaseStats(),
                path_icon="trait/MclslCombatCareer_"+(id=="casting"?"elemental":"martial") };
            status.base_stats[id=="break"?"armor":"multiplier_speed"]=id=="break"?-12:id=="casting"?-1f:-0.35f;
            AssetManager.status.add(status);
        }
        // 灵契共鸣给予主人的 +10% 伤害（契灵增伤在伤害结算里另行加算）。
        var resonance=new StatusAsset { id="mclsl_career_resonance",duration=8,base_stats=new BaseStats(),
            path_icon="trait/MclslCombatCareer_spirit" };
        resonance.base_stats["multiplier_damage"]=0.10f;
        AssetManager.status.add(resonance);
        // 御灵破势专用的 20% 减速（原 mclsl_career_slow 为 35%，其他职业不改）。
        var contractSlow=new StatusAsset { id="mclsl_career_contract_slow",duration=4,base_stats=new BaseStats(),
            path_icon="trait/MclslCombatCareer_spirit" };
        contractSlow.base_stats["multiplier_speed"]=-0.20f;
        AssetManager.status.add(contractSlow);
        // Templates supply native animal AI; living-resources binds the authored spirits.
        string[] templates={"wolf","turtle","butterfly","sheep"};
        var fighter=AssetManager.actor_library.get("wolf");
        for(int i=0;i<4;i++)
        {
            var asset=AssetManager.actor_library.clone("mclsl_career_spirit_"+i,templates[i]);
            asset.name_locale="mclsl_career_spirit_"+i;
            MclslLocalizationBridge.RegisterKey(asset.name_locale,new[]{"契灵·狼","契灵·岩龟","契灵·雷隼","契灵·鹿"}[i]);
            asset.default_subspecies_traits=new List<string>(asset.default_subspecies_traits);
            asset.default_subspecies_traits.RemoveAll(t=>t.StartsWith("reproduction_",StringComparison.Ordinal));
            asset.default_subspecies_traits.Add("reproduction_none");
            asset.can_evolve_into_new_species=false;asset.source_meat=false;asset.source_meat_insect=false;
            asset.resources_given=new List<ResourceContainer>();asset.count_as_unit=false;
            asset.has_baby_form=false;asset.use_phenotypes=false;asset.has_advanced_textures=false;
            string path="actors/CareerSpirits/"+i+"/";
            asset.texture_id=asset.id;
            asset.texture_asset=new ActorTextureSubAsset(path,false);
            asset.texture_asset.texture_path_main=path+"main";
            asset.texture_asset.loadShadow();
            asset.need_colored_sprite=false;
            asset.animation_idle=new[]{"idle_0","idle_1","idle_2","idle_3"};
            asset.animation_walk=new[]{"walk_0","walk_1","walk_2","walk_3","walk_4","walk_5","walk_6","walk_7"};
            asset.animation_swim=asset.animation_walk;
            asset.animation_idle_speed=0.18f;asset.animation_walk_speed=0.12f;
            asset.animation_swim_speed=0.12f;asset.animation_speed_based_on_walk_speed=false;
            asset.disable_jump_animation=true;
            asset.has_override_sprite=true;
            asset.get_override_sprite=ContractPetSprite;
            // Contract spirits read at two-thirds of the authored actor size;
            // artwork, frames and combat data stay untouched.
            asset.base_stats["scale"]=2f/3f;
            // 狼沿用原狼模板速度并额外 110%（改克隆独立 base_stats，不动共享模板）。
            if(i==0)
                asset.base_stats.set("multiplier_speed",asset.base_stats.get("multiplier_speed")+0.1f);
            // 龟/鹿原模板无主动作战 AI：沿用原版狼的作战配置（job/decision/attack），
            // 保留原生攻击节奏，避免逐帧自制 AI。隼保持无近战（手动远程结算）。
            if(i==1||i==3)
            {
                asset.skip_fight_logic=fighter.skip_fight_logic;
                asset.default_attack=fighter.default_attack;
                asset.aggression=fighter.aggression;
                asset.job_attacker=fighter.job_attacker;
                asset.job=fighter.job;
                asset.job_kingdom=fighter.job_kingdom;
                asset.job_baby=fighter.job_baby;
                // Vanilla initialization has already resolved and released decision_ids.
                asset.decision_ids=fighter.decision_ids;
                asset._cached_assets_decisions=fighter._cached_assets_decisions;
                asset._cached_assets_decisions_counter=fighter._cached_assets_decisions_counter;
            }
            asset.icon=asset.id;
            SpriteTextureLoader._cached_sprites["ui/Icons/"+asset.id]=
                SpriteTextureLoader.getSprite("ui/ContractPets/"+i);
            Sprite first=SpriteTextureLoader.getSprite(path+"main/idle_0");
            if(first==null)throw new InvalidOperationException("Missing spirit artwork: "+path);
            AssetManager.actor_library.loadTexturesAndSprites(asset);
            asset.cached_sprite=first;asset._cached_sprite=first;
        }
    }
    private static readonly HashSet<long> ActiveOwners = new();
    private sealed class PetAnimation
    {
        internal readonly MclslActorAnimationState State=new();
    }
    private static readonly System.Runtime.CompilerServices.ConditionalWeakTable<Actor,PetAnimation> PetAnimations=new();
    private static Sprite ContractPetSprite(Actor pet)
    {
        pet.checkAnimationContainer();
        bool moving=pet.isAlive()&&pet.is_moving;
        var animation=PetAnimations.GetOrCreateValue(pet);
        animation.State.Select(MclslRuntime.DisplayClock,moving,0,0,out double elapsed);
        var clip=moving?pet.animation_container.walking:pet.animation_container.idle;
        float interval=moving?pet.asset.animation_walk_speed:pet.asset.animation_idle_speed;
        int index=pet.isAlive()?(int)(elapsed/interval)%clip.frames.Length:0;
        return clip.frames[index];
    }
    private static readonly MclslOwnerRound OwnerRound = new();
    private static MclslModuleLoadState _loadState;
    private static string _loadedRaw;
    private static long _loadedWorldGeneration;
    private static bool _loadAttempted;
    private static int _generation;
    internal static void Wake(Actor actor)
    {
        if(actor?.data==null || !Battles.TryGetValue(actor.data.id,out var battle))return;
        ActiveOwners.Add(actor.data.id);
        if(battle.Career==5)
        {
            var summon=BoundSummon(battle);
            if(summon!=null)summon.Pulse=0;
        }
    }
    internal static void Track(Actor actor)
    {
        if(_loadState.Status!=MclslModuleLoadStatus.Ready)return;
        long id=MclslActorAccessor.Id(actor);
        int career=MclslCombatCareerSystem.Read(actor).Career;
        if(!Battles.ContainsKey(id))Battles[id]=new MclslCareerBattleState { Owner=id,Career=career };
        // 灵契师需要逐秒维持本命契灵（召唤/属性/跟随），即使当前没有攻击目标也要保持活跃。
        if(actor.has_attack_target||career==5)ActiveOwners.Add(id);
    }
    private static MclslCareerBattleState Battle(Actor actor) { Track(actor);ActiveOwners.Add(MclslActorAccessor.Id(actor));return Battles[MclslActorAccessor.Id(actor)]; }
    private static bool Passive(Actor actor,int tier)=>MclslCombatCareerSystem.Passive(actor,tier);
    internal static void Clear(){_generation++;Battles.Clear();ActiveOwners.Clear();OwnerRound.Clear();SummonOwners.Clear();Protections.Clear();_directPetDamage=false;_loadState.Clear();_loadedRaw=null;_loadAttempted=false;_loadedWorldGeneration=0;}
    internal static void Save()
    {
        if(!_loadState.CanSave || World.world?.map_stats==null)return;
        foreach (long id in Battles.Keys)
            if(MclslActorRegistry.ResolveKnownOrWorld(id,out Actor actor))
                MclslCombatCareerSystem.Write(actor,MclslCombatCareerSystem.Read(actor));
        foreach(var battle in Battles.Values)battle.Clock=Now;
        World.world.map_stats.custom_data??=new SaveCustomData();
        string raw=JsonConvert.SerializeObject(Battles.Values);
        World.world.map_stats.custom_data.set(SaveKey,raw);
        _loadedRaw=raw;
    }
    internal static void Load()
    {
        if(World.world?.map_stats==null){Clear();return;}
        string data="";World.world.map_stats.custom_data?.get(SaveKey,out data,"");
        long worldGeneration=MclslWorldContext.Generation;
        if(_loadAttempted&&_loadedWorldGeneration==worldGeneration&&_loadedRaw==data)return;
        Clear();
        try
        {
            if(data.Length>0)MclslCareerStateValidation.LoadBattles(data,Battles,SummonOwners,ActiveOwners,Now);
            _loadState.Ready();
        }
        catch(Exception ex)
        {
            Clear();_loadState.Fault();
            MclslDiagnostics.Error("career-battle-load",ex.ToString());
        }
        finally
        {
            // Remember failures too. Save updates this reference to the stored
            // string so it does not retain a second, obsolete JSON document.
            _loadedRaw=data;_loadedWorldGeneration=worldGeneration;_loadAttempted=true;
        }
    }
    internal static void RemoveOwner(Actor actor)
    {
        long id=MclslActorAccessor.Id(actor);
        ActiveOwners.Remove(id);
        if(!Battles.TryGetValue(id,out var battle))return;
        // A：存活才补结算（换职业/主动移除等），死亡不结算
        if(MclslActorAccessor.Alive(actor)&&(battle.BoutHostileHit||battle.BoutCast)) SettleBout(actor,battle);
        // 主动结束契约（存活主人转职/失去职业等）：清理活宠前写入“已有截止与 Now+30 的较大值”，
        // 防止反复转职立刻获得满血契灵。类型选择与冷却在 SetCareer/HandleRemoved 之间不重置。
        if(battle.Career==5&&MclslActorAccessor.Alive(actor))
        {
            var contractState=MclslCombatCareerSystem.Read(actor);
            contractState.NextSummonAt=MclslContractRules.ExtendCooldown(contractState.NextSummonAt,Now);
            MclslCombatCareerSystem.Write(actor,contractState);
        }
        foreach(var summon in battle.Summons)
        {
            SummonOwners.Remove(summon.Unit);
            if(MclslActorRegistry.ResolveKnownOrWorld(summon.Unit,out var unit)&&MclslActorAccessor.Alive(unit))
                unit.dieAndDestroy((AttackType)11);
        }
        actor.finishStatusEffect("mclsl_career_casting");actor.finishStatusEffect("mclsl_career_resonance");Battles.Remove(id);
        foreach(long key in Protections.Where(p=>p.Key==id||p.Value.Owner==id).Select(p=>p.Key).ToArray()) Protections.Remove(key);
    }
    private static Actor Resolve(long id) => MclslActorAccessor.Resolve(id);
    private static bool Enemy(Actor owner,Actor target)=>MclslCombatTargets.IsEnemy(owner,target);
    // Allocation-free membership tests used on the per-decision / per-hit paths
    // that previously built a LINQ Any() closure over the zone list.
    private static bool ZoneHasTier(MclslCareerBattleState battle,int tier)
    {
        for(int i=0;i<battle.Zones.Count;i++)if(battle.Zones[i].Tier==tier)return true;
        return false;
    }
    // Reusable scan buffers: Nearby always hands callers a fresh array copy, so the
    // scratch list/set is already free whenever a caller runs and may trigger a
    // nested (re-entrant) Nearby from a damage callback. This removes the per-scan
    // List+HashSet allocations that the earlier dedup still paid on every target scan.
    private static readonly List<Actor> NearbyScratch=new();
    private static readonly HashSet<Actor> NearbySeen=new();
    private static Actor[] Nearby(Actor actor,WorldTile tile,float radius)
    {
        long sample=MclslPerformanceProbe.Begin();
        try { return NearbyCore(actor,tile,radius); }
        finally { MclslPerformanceProbe.End("战斗.职业目标扫描",sample); }
    }
    private static Actor[] NearbyCore(Actor actor,WorldTile tile,float radius)
    {
        // Single pass with reference dedup (same ordering as the former
        // Where(Alive).Distinct().ToArray()) plus one diagnostic count.
        var units=Finder.getUnitsFromChunk(tile,1,radius,false);
        var result=NearbyScratch;result.Clear();
        var seen=NearbySeen;seen.Clear();
        foreach(var unit in units)
        {
            if(unit==null||!MclslActorAccessor.Alive(unit))continue;
            if(seen.Add(unit))result.Add(unit);
        }
        MclslPerformanceProbe.RecordCombatTargetScan(result.Count);
        return result.ToArray();
    }
    private static bool Friendly(Actor owner,Actor candidate)
        => candidate==owner || owner.kingdom!=null&&candidate.kingdom==owner.kingdom;
    private static MclslCareerMark Mark(MclslCareerBattleState battle,Actor target)
    {
        long id=MclslActorAccessor.Id(target);
        if(!battle.Marks.TryGetValue(id,out var mark)||mark.Expires<Now)
            battle.Marks[id]=mark=new MclslCareerMark();
        mark.Expires=Now+15;return mark;
    }
    internal static void Tick()
    {
        long sample=MclslPerformanceProbe.Begin();
        try { TickCore(); }
        finally { MclslPerformanceProbe.End("战斗.职业逻辑",sample); }
    }
    private static void TickCore()
    {
        if(_loadState.Status!=MclslModuleLoadStatus.Ready||World.world==null||Config.paused||MclslFrameDeadline.Expired)return;
        int generation=_generation;
        if(!OwnerRound.InProgress)OwnerRound.Begin(ActiveOwners);
        while(OwnerRound.InProgress)
        {
            if(generation!=_generation)return;
            // Retain the next owner across the shared 4/5ms frame deadline.
            if(MclslFrameDeadline.Expired)return;
            if(!OwnerRound.TryTake(ActiveOwners,out long ownerId)||!Battles.TryGetValue(ownerId,out var battle))continue;
            Actor owner=Resolve(battle.Owner);
            if(!MclslActorAccessor.Alive(owner))
            {
                if(owner!=null)RemoveOwner(owner);
                else {foreach(var summon in battle.Summons)
                    {SummonOwners.Remove(summon.Unit);Actor orphan=Resolve(summon.Unit);if(MclslActorAccessor.Alive(orphan))orphan.dieAndDestroy((AttackType)11);}
                    Battles.Remove(battle.Owner);ActiveOwners.Remove(battle.Owner);}
                continue;
            }
            var ownerState=MclslCombatCareerSystem.Read(owner);
            if(ownerState.Career!=battle.Career){RemoveOwner(owner);continue;}
            // 灵契师即使无攻击目标/无契灵也要保持活跃：需要逐秒尝试脱战召唤与契约维护。
            if(battle.Cast==null && battle.Zones.Count==0 && battle.Summons.Count==0
                && battle.LastAction==0 && !owner.has_attack_target && ownerState.Career!=5)
            {ActiveOwners.Remove(battle.Owner);continue;}
            if(battle.LastAction>0&&Now-battle.LastAction>15)
            {SettleBout(owner,battle);battle.BoutHostileHit=false;battle.BoutCast=false;battle.Marks.Clear();battle.Elements=0;battle.LastAction=0;}
            if(battle.Cast!=null) TickCast(owner,battle);
            if(generation!=_generation)return;
            TickZones(owner,battle);
            if(generation!=_generation)return;
            if(ownerState.Career==5) TickSpirit(owner,battle,ownerState);
            if(generation!=_generation)return;
            if(Now>=battle.NextDecision)
            {
                battle.NextDecision=Now+0.25;
                TryCast(owner);
            }
        }
    }
    internal static bool TryCast(Actor actor)
    {
        if(_loadState.Status!=MclslModuleLoadStatus.Ready)return false;
        if(!MclslCombatCareerSystem.Applicable(actor))return false;
        var state=MclslCombatCareerSystem.Read(actor);
        if(state.Career<0||!MclslActorAccessor.IsCultivator(actor))return false;
        var battle=Battle(actor);if(battle.Cast!=null)return true;
        if(state.Career==5)
        {
            Actor pet=BoundPet(battle);
            if(!actor.has_attack_target && actor.getHealth()>=actor.getMaxHealth()
                && (pet==null||pet.getHealth()>=pet.getMaxHealth()))return false;
            return TryCastSpirit(actor,state,battle,actor.attack_target as Actor);
        }
        if(actor.attack_target is not Actor target||!Enemy(actor,target))return false;
        int usable=Math.Min(state.Rank,MclslRealmIds.Index(MclslActorAccessor.Realm(actor))+1);
        for(int tier=usable;tier>=1;tier--)
        {
            var skill=MclslCombatCareerCatalog.Skill(state.Career,tier);
            if(state.Cooldowns[tier-1]>Now||MclslSpellSystem.CurrentMana(actor)<Mana(actor,skill))continue;
            if(skill.Item.Length>0&&MclslBagSystem.Count(MclslBagSystem.Read(actor),skill.Item)<1)continue;
            if((state.Career==1||state.Career==2||state.Career==3)&&tier==4 && actor.getHealth()>actor.getMaxHealth()*0.75f)continue;
            if(state.Career==4&&ZoneHasTier(battle,tier))continue;
            if(Vector2.Distance(actor.current_position,target.current_position)>(state.Career==1?4:10))continue;
            battle.Cast=new MclslCareerCast { Tier=tier,Target=MclslActorAccessor.Id(target),Due=Now+skill.Preparation };
            if(skill.Preparation>0){actor.stopMovement();actor.addStatusEffect("mclsl_career_casting",skill.Preparation+0.1f);}
            MclslSpellEffect.Show(actor,target,skill.Id,phase:"cast",duration:Math.Max(0.12f,skill.Preparation));
            if(skill.Preparation==0)TickCast(actor,battle);
            return true;
        }
        return false;
    }
    internal static int Mana(Actor actor,MclslCareerSkill skill)
        => Mathf.CeilToInt(skill.Mana*((skill.Career==2||skill.Career==3)&&Passive(actor,1)?0.9f:1f));
    private static void TickCast(Actor actor,MclslCareerBattleState battle)
    {
        var cast=battle.Cast;var skill=MclslCombatCareerCatalog.Skill(battle.Career,cast.Tier);
        if(cast.Phase==0 && (actor.hasStatus("mclsl_career_interrupt")||actor.hasStatus("mclsl_spell_shock")||actor.hasStatus("frozen")))
        {Interrupt(actor);return;}
        if(Now<cast.Due)return;
        Actor target=Resolve(cast.Target);
        // 灵契师 2-5 阶的受益者是契灵/主人，不要求敌对目标；其余仍须敌对目标。
        bool benefit=battle.Career==5&&cast.Tier>=2;
        if(benefit)
        {
            if(!MclslActorAccessor.Alive(target)||!HasLivingPet(battle))
            {MclslSpellEffect.CancelCareerCast(actor,skill.Id);battle.Cast=null;actor.finishStatusEffect("mclsl_career_casting");return;}
        }
        else if(!Enemy(actor,target)){battle.Cast=null;actor.finishStatusEffect("mclsl_career_casting");return;}
        if(cast.Phase==0)
        {
            var state=MclslCombatCareerSystem.Read(actor);
            int mana=MclslSpellSystem.CurrentMana(actor),cost=Mana(actor,skill);
            if(state.Career!=battle.Career || state.Rank<skill.Tier
                || !MclslActorAccessor.IsCultivator(actor)
                || MclslRealmIds.Index(MclslActorAccessor.Realm(actor))<skill.Tier-1
                || state.Cooldowns[skill.Tier-1]>Now || mana<cost
                || skill.Item.Length>0&&MclslBagSystem.Count(MclslBagSystem.Read(actor),skill.Item)<1
                || (battle.Career==5&&skill.Tier>=2&&!HasLivingPet(battle)))
            {
                MclslSpellEffect.CancelCareerCast(actor,skill.Id);
                battle.Cast=null;actor.finishStatusEffect("mclsl_career_casting");return;
            }
            if(skill.Item.Length>0)
            {
                var bag=MclslBagSystem.Read(actor);MclslBagSystem.Remove(bag,skill.Item);MclslBagSystem.Write(actor,bag);
            }
            MclslActorAccessor.Set(actor,MclslActorDataKeys.ManaCurrent,mana-cost);
            state.Cooldowns[skill.Tier-1]=Now+skill.Cooldown*(battle.Career==0&&skill.Tier==4&&Passive(actor,4)?0.85:1);
            actor.finishStatusEffect("mclsl_career_casting");
            cast.Phase=1;cast.Due=Now+0.2;
            string showPhase=skill.Career==5?(skill.Tier>=2?"area":"travel"):skill.Career==4?"area":"travel";
            MclslSpellEffect.Show(actor,target,skill.Id,phase:showPhase,duration:0.2f);
            if(Now>=battle.NextAudio){MusicBox.playSoundVisibleOnly(actor.asset.sound_attack,actor.current_tile);battle.NextAudio=Now+0.3;}
            MclslCombatCareerSystem.Write(actor,state);
            return;
        }
        battle.Cast=null;Execute(actor,target,battle,skill);
    }
    internal static void Interrupt(Actor actor)
    {
        if(!Battles.TryGetValue(MclslActorAccessor.Id(actor),out var battle)||battle.Cast==null||battle.Cast.Phase!=0)return;
        var state=MclslCombatCareerSystem.Read(actor);
        var skill=MclslCombatCareerCatalog.Skill(battle.Career,battle.Cast.Tier);
        MclslSpellEffect.CancelCareerCast(actor,skill.Id);
        MclslActorAccessor.Set(actor,MclslActorDataKeys.ManaCurrent,Math.Max(0,MclslSpellSystem.CurrentMana(actor)-Mathf.CeilToInt(Mana(actor,skill)*0.2f)));
        state.Cooldowns[skill.Tier-1]=Now+3;battle.Cast=null;actor.finishStatusEffect("mclsl_career_casting");
        MclslSpellEffect.Show(actor,null,skill.Id,phase:"cancel",duration:0.15f);
        MclslCombatCareerSystem.Write(actor,state);
    }
    private static void Execute(Actor owner,Actor target,MclslCareerBattleState battle,MclslCareerSkill skill)
    {
        int c=skill.Career,t=skill.Tier;battle.BoutCast=true;battle.LastAction=Now;
        if(c==4)
        {
            WorldTile tile=t==2||t==4?owner.current_tile:target.current_tile;
            battle.Zones.Add(new MclslCareerZone { Tier=t,X=tile.pos.x,Y=tile.pos.y,Expires=Now+(6+t)*(Passive(owner,2)?1.2:1),Pulse=Now });
        }
        else if(c==5)
        {
            ExecuteSpirit(owner,target,battle,skill);
        }
        else if(t==4 && c is 1 or 2 or 3)
        {
            int friendLimit=c==3?3:1;
            Actor[] friendUnits=Nearby(owner,owner.current_tile,5);
            for(int fi=0;fi<friendUnits.Length && friendLimit>0;fi++)
            {
                Actor ally=friendUnits[fi];
                if(!Friendly(owner,ally))continue;
                friendLimit--;
                float before=ally.getHealth();ally.restoreHealthPercent(c==3?0.12f:0.08f);
                if(ally==owner)battle.GuardUntil=Now+6+(c==3&&Passive(owner,4)?2:0);
                else {ally.addStatusEffect("mclsl_career_slow",0.01f);AddProtection(ally,owner,6);}
                MclslSpellEffect.Show(owner,ally,skill.Id,phase:"hit",duration:0.6f);
                if(before<ally.getHealth()&&ally.has_attack_target)Touch(owner);
            }
            if(c==2){MclslSpellSystem.RestoreMana(owner,0.04f);if(battle.FullCycle)Touch(owner);}
        }
        else
        {
            // Former single line was Nearby(...).Where(Enemy).OrderBy(a==target?0:1)
            // .Take(n).ToArray() for multi-target skills, else new[]{target}.
            // Reproduced with one scan: main target first (when it is hostile and
            // present in the scan), then remaining enemies in scan order, capped at
            // skill.Targets. The scan array is a copy, so Hits that re-enter nearby
            // code cannot disturb it.
            if(skill.Targets<=1) Hit(owner,target,battle,skill);
            else
            {
                Actor[] scanned=Nearby(owner,target.current_tile,4);
                int remaining=skill.Targets;
                bool mainInScan=false;
                for(int i=0;i<scanned.Length;i++)if(scanned[i]==target){mainInScan=true;break;}
                if(mainInScan&&Enemy(owner,target)){Hit(owner,target,battle,skill);remaining--;}
                for(int i=0;i<scanned.Length && remaining>0;i++)
                {
                    Actor enemy=scanned[i];
                    if(enemy==target||!Enemy(owner,enemy))continue;
                    Hit(owner,enemy,battle,skill);remaining--;
                }
            }
        }
    }
    private static void Hit(Actor owner,Actor target,MclslCareerBattleState battle,MclslCareerSkill skill)
    {
        int c=skill.Career,t=skill.Tier;var mark=Mark(battle,target);
        float power=skill.Power*(1+0.05f*(MclslCombatCareerSystem.Read(owner).Mastery[t-1]-1));
        power*=1f+MclslPhysiqueSystem.CareerDamagePercent(owner,c)/100f;
        if(c==0)
        {
            if(Passive(owner,1))power*=1.1f;
            if(t==2&&mark.SwordHits>0)power*=1.25f;
            if(t>=3){power*=1+battle.Sword*0.08f;if(t==5&&battle.Sword==5&&Passive(owner,5))power*=1.25f;battle.Sword=0;}
            if(Passive(owner,2)&&mark.SwordHits>=2){target.addStatusEffect("mclsl_career_break",4);PassiveFx(owner,2,target);}
            if(Passive(owner,3))battle.Sword=Math.Min(5,battle.Sword+1);
        }
        if(c==1)
        {
            if(t==2){Interrupt(target);target.addStatusEffect("mclsl_career_interrupt",1);}
            if(t>=3){power*=1+battle.Rage*0.1f;if(t==5)battle.Rage=0;}
            if(battle.Counter&&Passive(owner,5)){power*=1.25f;battle.Counter=false;PassiveFx(owner,5,target);}
            if(t==3)target.addStatusEffect("mclsl_career_slow",2);
        }
        if(c==2)
        {
            int element=t==1?1:t==2?2:t==3?4:0;
            int prior=battle.Elements;
            if(Passive(owner,2))battle.Elements|=element;
            if(t==2)target.addStatusEffect("mclsl_career_slow",3);
            if((prior&(prior-1))!=0){if(t>=3){power*=Passive(owner,3)?1.5f:1.25f;}}
            if(battle.Elements==7){battle.FullCycle=true;PassiveFx(owner,3,target);}
            if(t==5&&battle.FullCycle&&Passive(owner,5)){power*=1.3f;battle.FullCycle=false;}
            if(Passive(owner,4)&&battle.LastElement!=0&&element!=0&&battle.LastElement!=element){MclslSpellSystem.RestoreMana(owner,0.02f);PassiveFx(owner,4,owner);}
            if(element!=0)battle.LastElement=element;if(t>=3)battle.Elements=0;
        }
        if(c==3)
        {
            if(t==2){target.addStatusEffect("mclsl_career_interrupt",1.2f);}
            if(t>=3){power*=1+mark.Sigils*0.15f;if(mark.Sigils>=3){if(t==5&&Passive(owner,5))power*=1.25f;}mark.Sigils=0;}
            else if(Passive(owner,2))mark.Sigils=Math.Min(5,mark.Sigils+(t==2&&Passive(owner,3)?2:1));
        }
        int health=target.getHealth();
        MclslSpellCasting.DealDamage(owner,target,Math.Max(1,owner.stats.get("damage"))*power,skill.Law);
        if(target.getHealth()<health) HostileHit(owner);
        MclslSpellEffect.Show(owner,target,skill.Id,phase:"hit",duration:0.4f);
    }
    private static void TickZones(Actor owner,MclslCareerBattleState battle)
    {
        for(int i=battle.Zones.Count-1;i>=0;i--)
        {
            var zone=battle.Zones[i];if(Now>=zone.Expires){battle.Zones.RemoveAt(i);continue;}
            if(Now<zone.Pulse)continue;zone.Pulse=Now+1;
            WorldTile tile=World.world.GetTile(zone.X,zone.Y);var skill=MclslCombatCareerCatalog.Skill(4,zone.Tier);
            MclslSpellEffect.Show(owner,null,skill.Id,tile,phase:"area",duration:1f);
            Actor[] zoneUnits=Nearby(owner,tile,4);
            for(int ui=0;ui<zoneUnits.Length&&ui<8;ui++)
            {
                Actor unit=zoneUnits[ui];
                if(Enemy(owner,unit))
                {
                    if(zone.Tier==1){unit.addStatusEffect("mclsl_career_slow",Passive(owner,1)?2.4f:2);HostileHit(owner);}
                    if(zone.Tier==3||zone.Tier==5)
                    {
                        float factor=Passive(owner,3)&&owner.attack_target==unit?1.25f:1;
                        factor*=1f+MclslPhysiqueSystem.CareerDamagePercent(owner,4)/100f;
                        int before=unit.getHealth();
                        MclslSpellCasting.DealDamage(owner,unit,owner.stats.get("damage")*0.25f*factor,"土",true);
                        if(unit.getHealth()<before)HostileHit(owner);
                    }
                }
                else if(unit==owner||owner.kingdom!=null&&unit.kingdom==owner.kingdom)
                {
                    if(zone.Tier==2&&unit.has_attack_target && MclslSpellSystem.RestoreMana(unit,0.025f)>0)Touch(owner);
                    if(zone.Tier==4||zone.Tier==5)AddProtection(unit,owner,1.5);
                }
            }
        }
    }
    private sealed class Protection { public long Owner;public double Until; }
    private static readonly Dictionary<long,Protection> Protections=new();
    private static void AddProtection(Actor target,Actor owner,double duration)
        =>Protections[MclslActorAccessor.Id(target)]=new Protection{Owner=MclslActorAccessor.Id(owner),Until=Now+duration};
    internal static float Incoming(Actor victim,Actor attacker,float damage)
    {
        if(_loadState.Status!=MclslModuleLoadStatus.Ready)return damage;
        if(Protections.TryGetValue(MclslActorAccessor.Id(victim),out var protection)&&protection.Until>Now)
        {
            Actor owner=Resolve(protection.Owner);
            if(MclslActorAccessor.Alive(owner))
            {
                // One Career(owner) read and one Passive(owner,4) probe instead of
                // re-querying both twice on every protected hit.
                int ownerCareer=MclslCombatCareerSystem.Career(owner);
                bool ownerPassive4=ownerCareer==4&&Passive(owner,4);
                if(ownerCareer>=0)damage*=ownerPassive4?0.7f:0.8f;
                if(ownerCareer==4){Touch(owner);if(ownerPassive4)PassiveFx(owner,4,victim);}
            }
        }
        // 契约岩龟自身减伤 15%；不再常驻为主人提供 15-25 减伤。
        long victimId=MclslActorAccessor.Id(victim);
        if(SummonOwners.TryGetValue(victimId,out long petOwnerId)&&Battles.TryGetValue(petOwnerId,out var petBattle))
        {
            var petSummon=BoundSummon(petBattle);
            if(petSummon!=null&&petSummon.Unit==victimId&&petSummon.Kind==1)
                damage*=1f-(float)MclslContractRules.TurtleSelfReduction;
        }
        // Applicable already implies a valid state; read it once instead of letting
        // Career(victim) run a second Applicable+Read on this per-hit path.
        if(!MclslCombatCareerSystem.Applicable(victim)||MclslCombatCareerSystem.Read(victim).Career<0)return damage;
        var battle=Battle(victim);int career=battle.Career;
        if(battle.GuardUntil>Now)damage*=career==5?1f-(float)MclslContractRules.GuardReduction:0.7f;
        if(career==1)
        {
            if(Passive(victim,1))damage*=0.9f;
            if(Passive(victim,2)){damage*=0.92f;battle.Counter=true;Touch(victim);PassiveFx(victim,2,victim);}
            if(Passive(victim,3))battle.Rage=Math.Min(5,battle.Rage+1);
            if(Passive(victim,4)&&victim.getHealth()<victim.getMaxHealth()*0.3f){damage*=0.8f;Touch(victim);PassiveFx(victim,4,victim);}
        }
        if(career==5)
        {
            // 护主契纹：活宠距主人 6 格内时主人减伤 8%。
            var pet=BoundPet(battle);
            if(pet!=null&&Vector2.Distance(pet.current_position,victim.current_position)<=MclslContractRules.DeerRange)
                damage*=1f-(float)MclslContractRules.PassiveTwoReduction;
        }
        return damage;
    }
    internal static void EffectiveHit(Actor attacker,Actor target,int actualDamage)
    {
        if(_loadState.Status!=MclslModuleLoadStatus.Ready||actualDamage<=0)return;
        long id=MclslActorAccessor.Id(attacker);
        bool spirit=SummonOwners.TryGetValue(id,out long ownerId);
        if(spirit)attacker=Resolve(ownerId);
        // Read the cached state once rather than Career(attacker) re-running
        // Applicable+Read after the Applicable check already succeeded.
        if(!MclslCombatCareerSystem.Applicable(attacker)||MclslCombatCareerSystem.Read(attacker).Career<0||!Enemy(attacker,target))return;
        var battle=Battle(attacker);var mark=Mark(battle,target);mark.SwordHits++;
        if(battle.Career==1&&Passive(attacker,3))battle.Rage=Math.Min(5,battle.Rage+1);
        HostileHit(attacker);
        if(battle.Career==5)
        {
            if(spirit)mark.SpiritHit=Now;else mark.OwnerHit=Now;
            if(Passive(attacker,3)&&MclslContractRules.AssistReady(mark.OwnerHit,mark.SpiritHit,Now,mark.NextAssist))
            {
                mark.NextAssist=Now+MclslContractRules.AssistCooldownSeconds;
                HostileHit(attacker);PassiveFx(attacker,3,target);
                MclslSpellCasting.DealDamage(attacker,target,
                    Math.Max(1f,(float)(attacker.stats.get("damage")*MclslContractRules.AssistDamagePower)),"木");
            }
        }
    }
    internal static float SummonDamage(Actor attacker,float damage)
    {
        if(_loadState.Status!=MclslModuleLoadStatus.Ready)return damage;
        if(!SummonOwners.TryGetValue(MclslActorAccessor.Id(attacker),out long ownerId))return damage;
        Actor owner=Resolve(ownerId);
        if(!MclslActorAccessor.Alive(owner))return damage;
        if(_directPetDamage)return damage;
        var battle=Battle(owner);
        if(MclslCombatCareerSystem.Read(owner).Career!=battle.Career)return damage;
        // 契印 / 灵息灌注 / 灵契共鸣的契灵增伤按加算；不套用主人的 30% 伤害下限。
        bool marked=attacker.attack_target is Actor markTarget&&IsMarked(battle,markTarget);
        double factor=MclslContractRules.PetDamageFactor(marked,battle.PetBuffUntil>Now,battle.ResonanceUntil>Now,Passive(owner,5));
        return (float)(damage*factor);
    }
    // 职业战斗“动作标记”：刷新本场活跃时间（不再逐次记试炼）。
    private static void Touch(Actor owner)
    {
        var battle=Battle(owner);battle.LastAction=Now;
    }
    // 对敌有效命中：刷新活跃时间并记本场“敌对交锋”。
    private static void HostileHit(Actor owner)
    {
        var battle=Battle(owner);battle.LastAction=Now;battle.BoutHostileHit=true;
    }
    // 脱战结算：每场发放实战经验/试炼/施法熟练，再判定晋级。
    private static void SettleBout(Actor owner,MclslCareerBattleState battle)
    {
        var state=MclslCombatCareerSystem.Read(owner);
        int year=MclslRuntime.CurrentYear();
        if(state.BattleYear!=year){state.BattleYear=year;state.BattleExperience=0;}
        if(state.BattleExperience<4){state.BattleExperience++;state.Experience++;}
        if(battle.BoutHostileHit&&state.Rank>=1&&state.Rank<5) state.TrialProgress++;
        if(battle.BoutCast&&state.Rank>=1)
        {
            int tier=Math.Min(state.Rank,MclslRealmIds.Index(MclslActorAccessor.Realm(owner))+1);
            if(tier>0) MclslCombatCareerSystem.GainSkillExperience(state,tier,1);
        }
        MclslCombatCareerSystem.Promote(owner,state);MclslCombatCareerSystem.Write(owner,state);
    }
    private static void PassiveFx(Actor owner,int tier,Actor target)
    {
        var battle=Battle(owner);if(Now<battle.NextPassiveEffect)return;battle.NextPassiveEffect=Now+0.5;
        MclslSpellEffect.Show(owner,target,MclslCombatCareerCatalog.Skill(battle.Career,tier,true).Id,phase:"hit",duration:0.35f);
    }
}
