using System;
using MySimulatedLongevityRoad.Core;
using MySimulatedLongevityRoad.Data;
using MySimulatedLongevityRoad.Traits;

namespace MySimulatedLongevityRoad.Systems;

internal static class MclslCultivationAgeSanity
{
    internal const int SpiritualRootEntryAge = 5;

    internal static bool NeedsAgeRepair(Actor actor)
    {
        if (actor?.data == null || !MclslActorAccessor.Alive(actor)) return false;
        if (MclslBeastActorRegistration.IsOrdinary(actor) || MclslImmortalActorRegistration.IsImmortal(actor)) return false;
        // Empty-realm essence still has its own cap even for an adult. For an
        // existing realm, all age gates have opened by the ChangSheng threshold.
        return string.IsNullOrWhiteSpace(MclslActorAccessor.Realm(actor))
            || MclslActorAccessor.Age(actor) < MinimumAgeForRealm(MclslRealmIds.ChangSheng);
    }

    internal static bool RepairImpossibleYouthCultivation(Actor actor, int year)
    {
        if (actor?.data == null || !MclslActorAccessor.Alive(actor)) return false;
        // Ordinary beasts are born at their species' instinctive realm.
        if (MclslBeastActorRegistration.IsOrdinary(actor)) return false;

        long repairSample = MclslPerformanceProbe.Begin();
        int age = MclslActorAccessor.Age(actor);
        string realm = MclslActorAccessor.Realm(actor);
        bool ancientLaw = MclslActorAccessor.GetString(actor, MclslActorDataKeys.CultivationSystem, string.Empty)
            == MclslCultivationSystemIds.AncientLaw;
        int currentEssence = MclslCultivationGrowthSystem.CurrentTrueEssence(actor);
        string allowedRealm = HighestRealmAllowedAtAge(age);
        bool changed = false;
        // These two placed immortals are authored at their epoch's final realm.
        // Never treat their age as evidence
        // that their realm or true essence is invalid.
        bool placedImmortal = MclslImmortalActorRegistration.IsImmortal(actor);

        if (!placedImmortal && !string.IsNullOrWhiteSpace(realm)
            && MclslRealmIds.Index(realm) > MclslRealmIds.Index(allowedRealm))
        {
            string previousRealm = realm;
            if (string.IsNullOrWhiteSpace(allowedRealm))
            {
                MclslCultivationStateTransitions.ClearRealm(actor, year, "年岁尚浅，清理异常境界：" + MclslRealmIds.Display(previousRealm));
                realm = string.Empty;
            }
            else
            {
                MclslCultivationStateTransitions.TrySetRealm(
                    actor,
                    allowedRealm,
                    year,
                    "年岁尚浅，修复异常境界：" + MclslRealmIds.Display(previousRealm) + "回落至" + MclslRealmIds.Display(allowedRealm));
                realm = allowedRealm;
            }

            MclslDiagnostics.Cultivation(
                "age_sanity.realm_repair",
                "actor=" + MclslActorAccessor.Id(actor)
                + " year=" + year
                + " age=" + age
                + " previous=" + previousRealm
                + " allowed=" + allowedRealm);
            changed = true;
        }

        int cappedEssence = placedImmortal
            ? currentEssence
            : CapEssenceBeforeAgeGate(actor, realm, ancientLaw, age, currentEssence);
        if (cappedEssence < MclslCultivationGrowthSystem.CurrentTrueEssence(actor))
        {
            MclslCultivationGrowthSystem.SetTrueEssence(
                actor,
                realm,
                cappedEssence,
                ancientLaw,
                enforceRealmMinimum: !string.IsNullOrWhiteSpace(realm));
            MclslActorAccessor.Set(actor, MclslActorDataKeys.LastBreakthroughResult,
                "年岁尚浅，异常真元已压回当前年龄可承载范围");
            MclslDiagnostics.Cultivation(
                "age_sanity.essence_cap",
                "actor=" + MclslActorAccessor.Id(actor)
                + " year=" + year
                + " age=" + age
                + " realm=" + realm
                + " before=" + currentEssence
                + " after=" + cappedEssence);
            changed = true;
        }

        MclslPerformanceProbe.End("年度角色.年龄修复", repairSample);
        return changed;
    }

    internal static bool CanAttemptNextRealm(Actor actor, string currentRealm, out string reason)
    {
        reason = string.Empty;
        if (actor?.data == null || string.IsNullOrWhiteSpace(currentRealm)) return true;

        int currentIndex = MclslRealmIds.Index(currentRealm);
        if (currentIndex < 0 || currentIndex >= MclslRealmIds.Ordered.Length - 1) return true;

        string nextRealm = MclslRealmIds.Ordered[currentIndex + 1];
        int requiredAge = MinimumAgeForRealm(nextRealm);
        if (requiredAge <= 0) return true;

        int age = MclslActorAccessor.Age(actor);
        if (age >= requiredAge) return true;

        reason = "年岁尚浅，至少" + requiredAge + "岁方可尝试" + MclslRealmIds.Display(nextRealm);
        return false;
    }

    private static int CapEssenceBeforeAgeGate(Actor actor, string realm, bool ancientLaw, int age, int currentEssence)
    {
        int cap = int.MaxValue;
        if (string.IsNullOrWhiteSpace(realm))
        {
            if (age < MinimumAgeForRealm(MclslRealmIds.LianQi))
                cap = MclslRealmProgress.LianQiEntryMinimum - 1;
            else
                cap = MclslRealmProgress.NextRealmMinimum(MclslRealmIds.LianQi, ancientLaw) - 1;
        }
        else if (!CanAttemptNextRealm(actor, realm, out _))
        {
            int nextMinimum = MclslRealmProgress.NextRealmMinimum(realm, ancientLaw);
            if (nextMinimum > 0) cap = nextMinimum - 1;
        }

        if (cap == int.MaxValue) return currentEssence;
        return Math.Clamp(currentEssence, 0, Math.Max(0, cap));
    }

    private static string HighestRealmAllowedAtAge(int age)
    {
        string allowed = string.Empty;
        for (int i = 0; i < MclslRealmIds.Ordered.Length; i++)
        {
            string realm = MclslRealmIds.Ordered[i];
            if (age < MinimumAgeForRealm(realm)) break;
            allowed = realm;
        }
        return allowed;
    }

    private static int MinimumAgeForRealm(string realm) => realm switch
    {
        MclslRealmIds.LianQi => 7,
        MclslRealmIds.ZhuJi => 18,
        MclslRealmIds.JinDan => 60,
        MclslRealmIds.YuanYing => 150,
        MclslRealmIds.HuaShen => 500,
        MclslRealmIds.HeDao => 1000,
        MclslRealmIds.ChangSheng => 1600,
        _ => 0
    };
}
