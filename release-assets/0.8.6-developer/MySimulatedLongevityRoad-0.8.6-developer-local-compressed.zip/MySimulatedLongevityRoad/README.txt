MySimulatedLongevityRoad 0.8.6
Base commit: 3829fdd9fd06e85353759f59699fff45cd573694
Game build: 115
Only new worlds and current-format saves created by this 0.8.6 build are supported. Old archives are not imported, migrated or deleted.
Local build: consult FILE-MANIFEST.json for the exact current acceptance scope.
Install NeoModLoader, extract this directory into the game mods directory, and avoid duplicate installations.
Local-development snapshot. See the accompanying package record for acceptance scope.
Package-only PNG optimization: up to 256 palette colors; actor icons larger than 256 pixels were downscaled to a maximum side of 256. Color-profile and text-metadata PNGs remain unchanged.
Image encoding is palette optimized; acceptance scope is recorded in FILE-MANIFEST.json.
Recreate this package with tools/package-release.py --kind developer --compress-assets --local-development --output build/<fresh-directory>.
