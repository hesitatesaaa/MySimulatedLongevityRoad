using MySimulatedLongevityRoad.Modules;
using MySimulatedLongevityRoad.Queries;
using MySimulatedLongevityRoad.Systems;
using MySimulatedLongevityRoad.Systems.Visual;
using MySimulatedLongevityRoad.UI;
using UnityEngine;

namespace MySimulatedLongevityRoad.Core;

internal static class MclslRuntime
{
    private static bool _initialized;
    private static int _lastFrame = -1;
    private static int _frameCounter;
    private static int _lastYear = -1;

    internal static void Init()
    {
        if (_initialized) return;
        _initialized = true;
        MclslConfigLocalization.Init();
        MclslModuleHub.Init();
        MclslFpsOverlay.Ensure();
        MclslRuntimeDriver.Ensure();
    }

    internal static void OnWorldLoaded()
    {
        Init();
        MclslRuntimeDriver.Ensure();
        int year = CurrentYear();
        MclslModuleHub.OnWorldLoaded(year, MclslRuntimeSettings.CoreEnabled);
        MclslMaobaoArchiveManager.OnWorldLoaded();
        _lastYear = year;
        _frameCounter = 0;
    }

    internal static void Tick()
    {
        MclslDeveloperBridge.Tick();
        int unityFrame = Time.frameCount;
        if (unityFrame == _lastFrame) return;
        _lastFrame = unityFrame;

        long realtimeSample = MclslPerformanceProbe.Begin();
        using (MclslUnityProfiler.Sample("MCLS/Runtime/RealtimeModules"))
            MclslModuleHub.TickRealtime(MclslRuntimeSettings.CoreEnabled);
        MclslPerformanceProbe.End("实时模块", realtimeSample);
        MclslRuntimeWorkBudget.SampleFrame();
        if (!MclslRuntimeSettings.CoreEnabled) return;
        _frameCounter++;
        long frameSample = MclslPerformanceProbe.Begin();
        using (MclslUnityProfiler.Sample("MCLS/Runtime/FrameModules"))
            MclslModuleHub.TickFrame(_frameCounter, true);
        MclslPerformanceProbe.End("帧模块", frameSample);
        MclslPerformanceProbe.SampleFrame();
        if (_frameCounter % 15 == 0)
        {
            int year = CurrentYear();
            if (year != _lastYear)
            {
                _lastYear = year;
                using (MclslUnityProfiler.Sample("MCLS/Runtime/AnnualDispatch"))
                    MclslModuleHub.TickAnnual(year, true);
            }
        }
    }

    internal static void PrepareForSave()
    {
        MclslModuleHub.PrepareForSave();
    }

    internal static void ClearWorldState()
    {
        _lastFrame = -1;
        _frameCounter = 0;
        _lastYear = -1;
        MclslRuntimeWorkBudget.Clear();
        MclslBagSystem.ClearRuntime();
        MclslTianxuanMarket.ClearRuntime();
        MySimulatedLongevityRoad.Data.MclslHonorificNameCatalog.ClearRuntime();
        MclslModuleHub.Clear();
        MclslVisibleActorRenderLane.Clear();
        MclslRealmHaloVisualSystem.Clear();
    }

    internal static int CurrentYear()
    {
        try { return System.Math.Max(0, World.world?.map_stats?.year ?? 0); } catch { return 0; }
    }
}
